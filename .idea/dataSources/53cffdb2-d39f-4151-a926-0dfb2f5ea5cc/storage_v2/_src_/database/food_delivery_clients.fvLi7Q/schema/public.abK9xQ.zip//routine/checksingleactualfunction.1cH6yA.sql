create function checksingleactualfunction() returns trigger
    language plpgsql
as
$$
begin
    if new.is_active = true and old.is_active = false
        and exists(select *
                   from addresses a
                   where a.customer_id = new.customer_id
                     and a.is_active = true)
    then
        raise exception 'more then one active addresses';
    end if;

    return NEW;
end ;
$$;

alter function checksingleactualfunction() owner to postgres;

